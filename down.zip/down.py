import sys
import time
from time import sleep, strftime
from datetime import datetime
import threading
import webbrowser, os, re, json, random
import msvcrt
import webbrowser
import requests
import win32api
import threading




try:
    from faker import Faker
    from requests import session
    from colorama import Fore, Style
except:
    os.system("pip install faker")
    os.system("pip install requests")
    os.system("pip install colorama")
    os.system('pip install requests && pip install bs4 && pip install pystyle && pip install pycryptodome')
    print('__Minecraft Cheater Central SUIIIII__')
from pystyle import Add, Center, Anime, Colors, Colorate, Write, System

banner = r"""                                               



             _____ _           _         _                        __                             _       _       
            / ____| |         | |       | |                      / _|                           | |     | |      
           | (___ | |__  _   _| |_    __| | _____      ___ __   | |_ ___  _ __   _   _ _ __   __| | __ _| |_ ___ 
            \___ \| '_ \| | | | __|  / _` |/ _ \ \ /\ / / '_ \  |  _/ _ \| '__| | | | | '_ \ / _` |/ _` | __/ _ \
            ____) | | | | |_| | |_  | (_| | (_) \ V  V /| | | | | || (_) | |    | |_| | |_) | (_| | (_| | ||  __/
           |_____/|_| |_|\__,_|\__|  \__,_|\___/ \_/\_/ |_| |_| |_| \___/|_|     \__,_| .__/ \__,_|\__,_|\__\___|
                                                                                      | |                        
                                                                                      |_|                        
                                                                                                


                                                                                                                       
                                                                                                                       
                                              Press ENTER to exit.                                                                                      
"""[1:]
Anime.Fade(Center.Center(banner), Colors.blue_to_white, Colorate.Vertical, enter=True)
